import processing.core.PApplet;

public class Testprocess extends PApplet {
   int x,y;

    public static void main(String[] args) {
        PApplet.main("Testprocess",args);
    }

    @Override
    public void settings() {
        super.settings();
        size(600,500);
   }

    @Override
    public void draw() {
            background(101);
            stroke(255);
             x= 50;
             y=50;


            while(x<250) {

                    for (int i=x; i<=x+50;i++)
                    {
                        {
                        ellipse(i,y, 50, 50);
                      }
                      fill(i);


                }
                x = x + 50;
                y = y +100;
            }

    }
}



